package pizzaria.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private int id;
    private Cliente cliente;
    private LocalDateTime dataPedido;
    private String status;
    private double total;
    private List<ItemPedido> itens;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public Pedido() {
        this.itens  = new ArrayList<>();
        this.status = "Pendente";
    }

    public Pedido(Cliente cliente) {
        this();
        this.cliente = cliente;
    }

    public void adicionarItem(ItemPedido item) {
        itens.add(item);
        recalcularTotal();
    }

    public void recalcularTotal() {
        total = itens.stream().mapToDouble(ItemPedido::getSubtotal).sum();
    }

    public int getId()              { return id; }
    public void setId(int id)       { this.id = id; }

    public Cliente getCliente()               { return cliente; }
    public void setCliente(Cliente cliente)   { this.cliente = cliente; }

    public LocalDateTime getDataPedido()                    { return dataPedido; }
    public void setDataPedido(LocalDateTime dataPedido)     { this.dataPedido = dataPedido; }

    public String getStatus()               { return status; }
    public void setStatus(String status)    { this.status = status; }

    public double getTotal()              { return total; }
    public void setTotal(double total)    { this.total = total; }

    public List<ItemPedido> getItens()    { return itens; }
    public void setItens(List<ItemPedido> itens) {
        this.itens = itens;
        recalcularTotal();
    }

    @Override
    public String toString() {
        String data = dataPedido != null ? dataPedido.format(FMT) : "agora";
        return String.format("Pedido #%d | Cliente: %-20s | %s | Status: %-12s | Total: R$ %.2f",
                id, cliente.getNome(), data, status, total);
    }
}
