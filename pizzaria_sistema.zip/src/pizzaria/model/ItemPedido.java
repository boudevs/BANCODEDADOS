package pizzaria.model;

public class ItemPedido {
    private int id;
    private int pedidoId;
    private Pizza pizza;
    private int quantidade;
    private double precoUnitario;

    public ItemPedido() {}

    public ItemPedido(Pizza pizza, int quantidade) {
        this.pizza         = pizza;
        this.quantidade    = quantidade;
        this.precoUnitario = pizza.getPreco();
    }

    public int getId()              { return id; }
    public void setId(int id)       { this.id = id; }

    public int getPedidoId()               { return pedidoId; }
    public void setPedidoId(int pedidoId)  { this.pedidoId = pedidoId; }

    public Pizza getPizza()             { return pizza; }
    public void setPizza(Pizza pizza)   { this.pizza = pizza; }

    public int getQuantidade()                { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

    public double getPrecoUnitario()                    { return precoUnitario; }
    public void setPrecoUnitario(double precoUnitario)  { this.precoUnitario = precoUnitario; }

    public double getSubtotal() {
        return quantidade * precoUnitario;
    }

    @Override
    public String toString() {
        return String.format("  %dx %-25s R$ %.2f cada  =  R$ %.2f",
                quantidade, pizza.getNome(), precoUnitario, getSubtotal());
    }
}
