package pizzaria.dao;

import pizzaria.Conexao;
import pizzaria.model.Cliente;
import pizzaria.model.ItemPedido;
import pizzaria.model.Pedido;
import pizzaria.model.Pizza;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    // Salvar pedido completo (pedido + itens numa transação)
    public void inserir(Pedido pedido) {
        String sqlPedido = "INSERT INTO pedidos (cliente_id, total) VALUES (?, ?)";
        String sqlItem   = "INSERT INTO itens_pedido (pedido_id, pizza_id, quantidade, preco_unitario) VALUES (?, ?, ?, ?)";

        Connection conn = null;
        try {
            conn = Conexao.obterConexao();
            conn.setAutoCommit(false); // inicia transação

            // 1. Inserir o pedido
            PreparedStatement psPedido = conn.prepareStatement(sqlPedido, Statement.RETURN_GENERATED_KEYS);
            psPedido.setInt(1, pedido.getCliente().getId());
            psPedido.setDouble(2, pedido.getTotal());
            psPedido.executeUpdate();

            ResultSet keys = psPedido.getGeneratedKeys();
            if (keys.next()) pedido.setId(keys.getInt(1));

            // 2. Inserir cada item do pedido
            PreparedStatement psItem = conn.prepareStatement(sqlItem);
            for (ItemPedido item : pedido.getItens()) {
                psItem.setInt(1, pedido.getId());
                psItem.setInt(2, item.getPizza().getId());
                psItem.setInt(3, item.getQuantidade());
                psItem.setDouble(4, item.getPrecoUnitario());
                psItem.addBatch();
            }
            psItem.executeBatch();

            conn.commit(); // confirma tudo de uma vez
            System.out.println("✔ Pedido #" + pedido.getId() + " registrado com sucesso!");

        } catch (SQLException e) {
            // Se algo der errado, desfaz tudo
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            System.out.println("Erro ao registrar pedido: " + e.getMessage());
        } finally {
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    // Listar todos os pedidos com dados do cliente
    public List<Pedido> listarTodos() {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT p.id, p.data_pedido, p.status, p.total, " +
                     "c.id AS cli_id, c.nome, c.telefone, c.endereco " +
                     "FROM pedidos p JOIN clientes c ON p.cliente_id = c.id " +
                     "ORDER BY p.data_pedido DESC";

        try (Connection conn = Conexao.obterConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) lista.add(mapearPedido(rs));

        } catch (SQLException e) {
            System.out.println("Erro ao listar pedidos: " + e.getMessage());
        }

        return lista;
    }

    // Buscar pedidos por status
    public List<Pedido> listarPorStatus(String status) {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT p.id, p.data_pedido, p.status, p.total, " +
                     "c.id AS cli_id, c.nome, c.telefone, c.endereco " +
                     "FROM pedidos p JOIN clientes c ON p.cliente_id = c.id " +
                     "WHERE p.status = ? ORDER BY p.data_pedido DESC";

        try (Connection conn = Conexao.obterConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapearPedido(rs));

        } catch (SQLException e) {
            System.out.println("Erro ao listar pedidos: " + e.getMessage());
        }

        return lista;
    }

    // Buscar itens de um pedido
    public List<ItemPedido> buscarItensDoPedido(int pedidoId) {
        List<ItemPedido> itens = new ArrayList<>();
        String sql = "SELECT i.id, i.quantidade, i.preco_unitario, " +
                     "p.id AS pizza_id, p.nome, p.descricao, p.preco " +
                     "FROM itens_pedido i JOIN pizzas p ON i.pizza_id = p.id " +
                     "WHERE i.pedido_id = ?";

        try (Connection conn = Conexao.obterConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, pedidoId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Pizza pizza = new Pizza();
                pizza.setId(rs.getInt("pizza_id"));
                pizza.setNome(rs.getString("nome"));
                pizza.setDescricao(rs.getString("descricao"));
                pizza.setPreco(rs.getDouble("preco"));

                ItemPedido item = new ItemPedido();
                item.setId(rs.getInt("id"));
                item.setPedidoId(pedidoId);
                item.setPizza(pizza);
                item.setQuantidade(rs.getInt("quantidade"));
                item.setPrecoUnitario(rs.getDouble("preco_unitario"));
                itens.add(item);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao buscar itens: " + e.getMessage());
        }

        return itens;
    }

    // Atualizar status de um pedido
    public void atualizarStatus(int pedidoId, String novoStatus) {
        String sql = "UPDATE pedidos SET status = ? WHERE id = ?";

        try (Connection conn = Conexao.obterConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, novoStatus);
            ps.setInt(2, pedidoId);
            int linhas = ps.executeUpdate();

            if (linhas > 0)
                System.out.println("✔ Status atualizado para: " + novoStatus);
            else
                System.out.println("Pedido não encontrado.");

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar status: " + e.getMessage());
        }
    }

    // Relatório: total de vendas por período
    public void relatorioVendas() {
        String sql = "SELECT DATE(data_pedido) AS dia, COUNT(*) AS qtd_pedidos, SUM(total) AS faturamento " +
                     "FROM pedidos WHERE status != 'Cancelado' " +
                     "GROUP BY DATE(data_pedido) ORDER BY dia DESC LIMIT 30";

        try (Connection conn = Conexao.obterConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("\n--- RELATÓRIO DE VENDAS (últimos 30 dias) ---");
            System.out.printf("%-15s %-15s %-15s%n", "Data", "Pedidos", "Faturamento");
            System.out.println("-".repeat(45));

            double totalGeral = 0;
            int pedidosGeral = 0;
            while (rs.next()) {
                double fat = rs.getDouble("faturamento");
                int qtd    = rs.getInt("qtd_pedidos");
                totalGeral   += fat;
                pedidosGeral += qtd;
                System.out.printf("%-15s %-15d R$ %.2f%n",
                        rs.getString("dia"), qtd, fat);
            }
            System.out.println("-".repeat(45));
            System.out.printf("%-15s %-15d R$ %.2f%n", "TOTAL", pedidosGeral, totalGeral);

        } catch (SQLException e) {
            System.out.println("Erro ao gerar relatório: " + e.getMessage());
        }
    }

    // Relatório: pizzas mais vendidas
    public void relatorioPizzasMaisVendidas() {
        String sql = "SELECT p.nome, SUM(i.quantidade) AS total_vendido, SUM(i.quantidade * i.preco_unitario) AS receita " +
                     "FROM itens_pedido i JOIN pizzas p ON i.pizza_id = p.id " +
                     "GROUP BY p.id, p.nome ORDER BY total_vendido DESC";

        try (Connection conn = Conexao.obterConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("\n--- PIZZAS MAIS VENDIDAS ---");
            System.out.printf("%-30s %-15s %-15s%n", "Pizza", "Qtd Vendida", "Receita");
            System.out.println("-".repeat(60));

            while (rs.next()) {
                System.out.printf("%-30s %-15d R$ %.2f%n",
                        rs.getString("nome"),
                        rs.getInt("total_vendido"),
                        rs.getDouble("receita"));
            }

        } catch (SQLException e) {
            System.out.println("Erro ao gerar relatório: " + e.getMessage());
        }
    }

    // Mapear ResultSet → Pedido
    private Pedido mapearPedido(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setId(rs.getInt("cli_id"));
        cliente.setNome(rs.getString("nome"));
        cliente.setTelefone(rs.getString("telefone"));
        cliente.setEndereco(rs.getString("endereco"));

        Pedido pedido = new Pedido(cliente);
        pedido.setId(rs.getInt("id"));
        pedido.setStatus(rs.getString("status"));
        pedido.setTotal(rs.getDouble("total"));

        Timestamp ts = rs.getTimestamp("data_pedido");
        if (ts != null) pedido.setDataPedido(ts.toLocalDateTime());

        return pedido;
    }
}
