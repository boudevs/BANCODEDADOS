package pizzaria.dao;

import pizzaria.Conexao;
import pizzaria.model.Pizza;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PizzaDAO {

    // Cadastrar nova pizza
    public void inserir(Pizza pizza) {
        String sql = "INSERT INTO pizzas (nome, descricao, preco) VALUES (?, ?, ?)";

        try (Connection conn = Conexao.obterConexao();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, pizza.getNome());
            ps.setString(2, pizza.getDescricao());
            ps.setDouble(3, pizza.getPreco());
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) pizza.setId(keys.getInt(1));

            System.out.println("✔ Pizza cadastrada com sucesso! ID: " + pizza.getId());

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar pizza: " + e.getMessage());
        }
    }

    // Listar todo o cardápio
    public List<Pizza> listarTodas() {
        List<Pizza> lista = new ArrayList<>();
        String sql = "SELECT * FROM pizzas ORDER BY nome";

        try (Connection conn = Conexao.obterConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) lista.add(mapear(rs));

        } catch (SQLException e) {
            System.out.println("Erro ao listar cardápio: " + e.getMessage());
        }

        return lista;
    }

    // Buscar pizza pelo ID
    public Pizza buscarPorId(int id) {
        String sql = "SELECT * FROM pizzas WHERE id = ?";

        try (Connection conn = Conexao.obterConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);

        } catch (SQLException e) {
            System.out.println("Erro ao buscar pizza: " + e.getMessage());
        }

        return null;
    }

    // Atualizar preço de uma pizza
    public void atualizarPreco(int id, double novoPreco) {
        String sql = "UPDATE pizzas SET preco = ? WHERE id = ?";

        try (Connection conn = Conexao.obterConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, novoPreco);
            ps.setInt(2, id);
            ps.executeUpdate();

            System.out.println("✔ Preço atualizado com sucesso!");

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar preço: " + e.getMessage());
        }
    }

    // Mapear ResultSet → Pizza
    private Pizza mapear(ResultSet rs) throws SQLException {
        Pizza p = new Pizza();
        p.setId(rs.getInt("id"));
        p.setNome(rs.getString("nome"));
        p.setDescricao(rs.getString("descricao"));
        p.setPreco(rs.getDouble("preco"));
        return p;
    }
}
