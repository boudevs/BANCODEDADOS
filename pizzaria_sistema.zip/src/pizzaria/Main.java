package pizzaria;

import pizzaria.dao.ClienteDAO;
import pizzaria.dao.PedidoDAO;
import pizzaria.dao.PizzaDAO;
import pizzaria.model.Cliente;
import pizzaria.model.ItemPedido;
import pizzaria.model.Pedido;
import pizzaria.model.Pizza;

import java.util.List;
import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);
    static ClienteDAO clienteDAO = new ClienteDAO();
    static PizzaDAO   pizzaDAO   = new PizzaDAO();
    static PedidoDAO  pedidoDAO  = new PedidoDAO();

    public static void main(String[] args) {
        System.out.println("===========================================");
        System.out.println("       BEM-VINDO AO SISTEMA PIZZARIA      ");
        System.out.println("===========================================");

        int opcao;
        do {
            exibirMenuPrincipal();
            opcao = lerInt("Escolha: ");
            switch (opcao) {
                case 1 -> menuClientes();
                case 2 -> menuCardapio();
                case 3 -> menuPedidos();
                case 4 -> menuRelatorios();
                case 0 -> System.out.println("\nAté logo!");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }

    // ─── MENUS ────────────────────────────────────────────────

    static void exibirMenuPrincipal() {
        System.out.println("\n╔══════════════════════╗");
        System.out.println("║   MENU PRINCIPAL     ║");
        System.out.println("╠══════════════════════╣");
        System.out.println("║ 1. Clientes          ║");
        System.out.println("║ 2. Cardápio          ║");
        System.out.println("║ 3. Pedidos           ║");
        System.out.println("║ 4. Relatórios        ║");
        System.out.println("║ 0. Sair              ║");
        System.out.println("╚══════════════════════╝");
    }

    // ─── CLIENTES ─────────────────────────────────────────────

    static void menuClientes() {
        int op;
        do {
            System.out.println("\n--- CLIENTES ---");
            System.out.println("1. Cadastrar cliente");
            System.out.println("2. Listar todos");
            System.out.println("3. Buscar por nome");
            System.out.println("0. Voltar");
            op = lerInt("Escolha: ");
            switch (op) {
                case 1 -> cadastrarCliente();
                case 2 -> listarClientes();
                case 3 -> buscarCliente();
            }
        } while (op != 0);
    }

    static void cadastrarCliente() {
        System.out.println("\n-- Novo Cliente --");
        String nome     = lerTexto("Nome: ");
        String telefone = lerTexto("Telefone: ");
        String endereco = lerTexto("Endereço: ");
        clienteDAO.inserir(new Cliente(nome, telefone, endereco));
    }

    static void listarClientes() {
        List<Cliente> lista = clienteDAO.listarTodos();
        if (lista.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
            return;
        }
        System.out.println("\n-- Lista de Clientes --");
        lista.forEach(System.out::println);
    }

    static void buscarCliente() {
        String nome = lerTexto("Nome para buscar: ");
        List<Cliente> lista = clienteDAO.buscarPorNome(nome);
        if (lista.isEmpty()) System.out.println("Nenhum cliente encontrado.");
        else lista.forEach(System.out::println);
    }

    // ─── CARDÁPIO ─────────────────────────────────────────────

    static void menuCardapio() {
        int op;
        do {
            System.out.println("\n--- CARDÁPIO ---");
            System.out.println("1. Cadastrar pizza");
            System.out.println("2. Ver cardápio completo");
            System.out.println("3. Atualizar preço");
            System.out.println("0. Voltar");
            op = lerInt("Escolha: ");
            switch (op) {
                case 1 -> cadastrarPizza();
                case 2 -> listarCardapio();
                case 3 -> atualizarPreco();
            }
        } while (op != 0);
    }

    static void cadastrarPizza() {
        System.out.println("\n-- Nova Pizza --");
        String nome      = lerTexto("Nome: ");
        String descricao = lerTexto("Descrição: ");
        double preco     = lerDouble("Preço: R$ ");
        pizzaDAO.inserir(new Pizza(nome, descricao, preco));
    }

    static void listarCardapio() {
        List<Pizza> lista = pizzaDAO.listarTodas();
        if (lista.isEmpty()) {
            System.out.println("Nenhuma pizza cadastrada.");
            return;
        }
        System.out.println("\n===== CARDÁPIO =====");
        lista.forEach(System.out::println);
    }

    static void atualizarPreco() {
        listarCardapio();
        int id        = lerInt("ID da pizza: ");
        double preco  = lerDouble("Novo preço: R$ ");
        pizzaDAO.atualizarPreco(id, preco);
    }

    // ─── PEDIDOS ──────────────────────────────────────────────

    static void menuPedidos() {
        int op;
        do {
            System.out.println("\n--- PEDIDOS ---");
            System.out.println("1. Novo pedido");
            System.out.println("2. Listar todos os pedidos");
            System.out.println("3. Ver pedidos por status");
            System.out.println("4. Ver detalhes de um pedido");
            System.out.println("5. Atualizar status do pedido");
            System.out.println("0. Voltar");
            op = lerInt("Escolha: ");
            switch (op) {
                case 1 -> novoPedido();
                case 2 -> listarPedidos();
                case 3 -> pedidosPorStatus();
                case 4 -> detalhesPedido();
                case 5 -> atualizarStatusPedido();
            }
        } while (op != 0);
    }

    static void novoPedido() {
        // 1. Escolher cliente
        System.out.println("\n-- Novo Pedido --");
        String nomeBusca = lerTexto("Nome do cliente: ");
        List<Cliente> clientes = clienteDAO.buscarPorNome(nomeBusca);

        if (clientes.isEmpty()) {
            System.out.println("Cliente não encontrado. Cadastre-o primeiro.");
            return;
        }
        clientes.forEach(System.out::println);
        int clienteId = lerInt("ID do cliente: ");
        Cliente cliente = clienteDAO.buscarPorId(clienteId);
        if (cliente == null) { System.out.println("Cliente inválido."); return; }

        // 2. Montar o pedido com itens
        Pedido pedido = new Pedido(cliente);
        boolean adicionando = true;

        while (adicionando) {
            listarCardapio();
            int pizzaId = lerInt("ID da pizza (0 para finalizar): ");
            if (pizzaId == 0) { adicionando = false; continue; }

            Pizza pizza = pizzaDAO.buscarPorId(pizzaId);
            if (pizza == null) { System.out.println("Pizza inválida."); continue; }

            int qtd = lerInt("Quantidade: ");
            pedido.adicionarItem(new ItemPedido(pizza, qtd));
            System.out.printf("Adicionado: %dx %s%n", qtd, pizza.getNome());
        }

        if (pedido.getItens().isEmpty()) {
            System.out.println("Pedido cancelado — nenhum item adicionado.");
            return;
        }

        // 3. Confirmar
        System.out.println("\n-- Resumo do Pedido --");
        System.out.println("Cliente: " + cliente.getNome());
        pedido.getItens().forEach(System.out::println);
        System.out.printf("TOTAL: R$ %.2f%n", pedido.getTotal());
        String conf = lerTexto("Confirmar pedido? (s/n): ");

        if (conf.equalsIgnoreCase("s")) {
            pedidoDAO.inserir(pedido);
        } else {
            System.out.println("Pedido cancelado.");
        }
    }

    static void listarPedidos() {
        List<Pedido> lista = pedidoDAO.listarTodos();
        if (lista.isEmpty()) { System.out.println("Nenhum pedido encontrado."); return; }
        System.out.println("\n-- Todos os Pedidos --");
        lista.forEach(System.out::println);
    }

    static void pedidosPorStatus() {
        System.out.println("Status disponíveis: Pendente | Em preparo | Saiu para entrega | Entregue | Cancelado");
        String status = lerTexto("Status: ");
        List<Pedido> lista = pedidoDAO.listarPorStatus(status);
        if (lista.isEmpty()) System.out.println("Nenhum pedido com esse status.");
        else lista.forEach(System.out::println);
    }

    static void detalhesPedido() {
        listarPedidos();
        int id = lerInt("ID do pedido: ");
        List<ItemPedido> itens = pedidoDAO.buscarItensDoPedido(id);
        if (itens.isEmpty()) { System.out.println("Pedido não encontrado ou sem itens."); return; }
        System.out.println("\n-- Itens do Pedido #" + id + " --");
        itens.forEach(System.out::println);
        double total = itens.stream().mapToDouble(ItemPedido::getSubtotal).sum();
        System.out.printf("TOTAL: R$ %.2f%n", total);
    }

    static void atualizarStatusPedido() {
        listarPedidos();
        int id = lerInt("ID do pedido: ");
        System.out.println("1. Pendente");
        System.out.println("2. Em preparo");
        System.out.println("3. Saiu para entrega");
        System.out.println("4. Entregue");
        System.out.println("5. Cancelado");
        int op = lerInt("Novo status: ");
        String[] status = {"Pendente", "Em preparo", "Saiu para entrega", "Entregue", "Cancelado"};
        if (op >= 1 && op <= 5) pedidoDAO.atualizarStatus(id, status[op - 1]);
        else System.out.println("Opção inválida.");
    }

    // ─── RELATÓRIOS ───────────────────────────────────────────

    static void menuRelatorios() {
        int op;
        do {
            System.out.println("\n--- RELATÓRIOS ---");
            System.out.println("1. Vendas por dia");
            System.out.println("2. Pizzas mais vendidas");
            System.out.println("0. Voltar");
            op = lerInt("Escolha: ");
            switch (op) {
                case 1 -> pedidoDAO.relatorioVendas();
                case 2 -> pedidoDAO.relatorioPizzasMaisVendidas();
            }
        } while (op != 0);
    }

    // ─── HELPERS DE LEITURA ───────────────────────────────────

    static String lerTexto(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    static int lerInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                int val = Integer.parseInt(sc.nextLine().trim());
                return val;
            } catch (NumberFormatException e) {
                System.out.println("Digite um número inteiro válido.");
            }
        }
    }

    static double lerDouble(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Double.parseDouble(sc.nextLine().trim().replace(",", "."));
            } catch (NumberFormatException e) {
                System.out.println("Digite um valor válido (ex: 35.90).");
            }
        }
    }
}
